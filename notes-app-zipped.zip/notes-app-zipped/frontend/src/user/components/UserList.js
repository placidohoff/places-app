import React from "react";
import "./UserList.css";
import { UserItem } from "./UserItem";

/**
 * @author
 * @function UserList
 **/

export const UserList = ({ items }) => {
  if (items.length === 0) {
    return <div>No users found</div>;
  }

  return (
    <ul className="users-list">
      {items.map((user) => {
        return (
          <UserItem
            key={user.id}
            id={user.id}
            image={user.image}
            name={user.name}
            notesCount={user.notes.length}
          />
        );
      })}
    </ul>
  );
};
