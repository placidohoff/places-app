import React from "react";
import Avatar from "../../shared/components/UIElements/Avatar";
import Card from "../../shared/components/UIElements/Avatar";
import { Link } from "react-router-dom";

/**
 * @author
 * @function UserItem
 **/

export const UserItem = (props) => {
  return (
    <li className="user-item">
      <div
        className="user-item__content"
        style={{ display: "flex", border: "1px solid red" }}
      >
        {/* <Card> */}
          <Link to={`/${props.id}/notes`}>
            <div className="user-item__image">
              <Avatar image={props.image} alt={props.name} />
            </div>
            <div className="user-item__info">
              <h2>{props.name}</h2>
              <h3>
                {props.notesCount} {props.notesCount === 1 ? "Note" : "Notes"}
              </h3>
            </div>
          </Link>
        {/* </Card> */}
      </div>
    </li>
  );
};
