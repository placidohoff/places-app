import React from 'react'
import { NotebookList } from '../../notes/components/NotebookList'

/**
* @author
* @function UserNotes
**/

const notebooks = [
    {
        id: 'nbk0',
        ownerId: 'Test User',
        title: 'Biology',
        chapters: [
            {
                id: 'nbk0chp1',
                notebookId: 'nbk0',
                chapterTitle: 'Body Chemistry',
                notes: [
                    {
                        id: 'nbk0chp1n1',
                        chapterId: 'nbk0chp1',
                        meta: 'note',
                        note: ''
                    }
                ] 
            }
        ]
    },
    {
        title: 'Chemistry',
        chapters: [
            {data: '. . .'},
            {data: '. . .'}
        ]
    }
]

export const UserNotes = (props) => {
  return(
    <NotebookList items={notebooks} />
   )

 }