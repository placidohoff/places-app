import React from "react";
import Card from "../../shared/components/UIElements/Card";
import "./NotebookItem.css";

/**
 * @author
 * @function NotebookItem
 **/

export const NotebookItem = (props) => {
  return (
    <li className="notebook-item">
      <Card className="notebook-item__content">
        <div className="notebook-item__info">
          <h2>{props.notebook.title}</h2>
        </div>
      </Card>
    </li>
  );
};
