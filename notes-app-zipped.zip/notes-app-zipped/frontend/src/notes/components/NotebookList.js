import React from "react";
import { NotebookItem } from "./NotebookItem";
import "./NotebookList.css";

/**
 * @author
 * @function NotebookList
 **/

export const NotebookList = (props) => {
  if (props.items.length === 0) {
    return (
      <div className="place-list center">
        <Card>
          <h2>No notebooks found. Please create one</h2>
          <button>Create Notebook</button>
        </Card>
      </div>
    );
  }

  return (
    <ul className="place-list">
      {props.items.map((item) => (
        <NotebookItem notebook={item} key={item.id} id={item.id} title />
      ))}
    </ul>
  );
};
