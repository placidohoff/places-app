import React from 'react'
import { NavLink } from 'react-router-dom'
import './NavLinks.css'

/**
* @author
* @function NavLinks
**/

export const NavLinks = (props) => {
  return(
    <ul className='nav-links'>
        <li>
            <NavLink to="/" exact>ALL USERS</NavLink>
        </li>
        <li>
            <NavLink to="/u1/notes">MY NOTES</NavLink>
        </li>
        <li>
            <NavLink to="/notes/new">ADD NOTE</NavLink>
        </li>
        <li>
            <NavLink to="/auth">AUTHENTICATE</NavLink>
        </li>
    </ul>
   )

 }