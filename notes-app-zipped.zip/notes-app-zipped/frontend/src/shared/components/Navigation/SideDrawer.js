import React from "react";
import ReactDOM from "react-dom";
import "./SideDrawer.css";
import { CSSTransition } from "react-transition-group";

/**
 * @author
 * @function SideDrawer
 **/

export const SideDrawer = (props) => {
  // return <aside className="side-drawer">
  //   {props.children}
  // </aside>;
  return ReactDOM.createPortal(
    <CSSTransition
      in={props.show}
      timeout={2000}
      classNames="slide-in-left"
      mountOnEnter
      unmountOnExit
      appear
    >
      <aside className="side-drawer" onClick={props.onClick}>{props.children}</aside>
    </CSSTransition>,
    document.getElementById("drawer-hook")
  );
};
