import React from "react";
import ReactDOM  from 'react-dom'
import "./SideDrawer.css";

/**
 * @author
 * @function SideDrawer
 **/

export const SideDrawer = (props) => {
  // return <aside className="side-drawer">
  //   {props.children}
  // </aside>;
  return ReactDOM.createPortal(<aside className="side-drawer">
  {props.children}
</aside>, document.getElementById('drawer-hook'))
};
