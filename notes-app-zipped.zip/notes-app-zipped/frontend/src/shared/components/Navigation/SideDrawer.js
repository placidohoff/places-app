import React from "react";
// import { ReactDOM } from 'react-dom'
import "./SideDrawer.css";

/**
 * @author
 * @function SideDrawer
 **/

export const SideDrawer = (props) => {
  return <aside className="side-drawer">
    {props.children}
  </aside>;
  // return ReactDOM.createPortal(content, document.getElementById('drawer-hook'))
};
