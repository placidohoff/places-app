const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose')
mongoose.set('strictQuery', true)

const placesRoutes = require('./routes/places-route');
const usersRoutes = require('./routes/users-route')
const notesRoutes = require('./routes/notes-route')
const HttpError = require('./models/http-error')


const app = express();

//We must parse incoming data for post routes etc:
//must parse before any other middleware?
app.use(bodyParser.json());


//Routing Middleware:
//Routes will only be forwarded to the respective middleware if it is prepended with the specified route prefix
app.use('/api/places', placesRoutes);

app.use('/api/users', usersRoutes);

app.use('/api/notes', notesRoutes);

app.use((req, res, next) => {
    const err = new HttpError("Cannot find route", 404);
    throw err;
})

//Middleware with 4params is registered as error handler:
app.use((error, req, res, next) => {
    if (res.headerSent) {
        return next(error)
    }
    res.status(error.code || 500)
    res.json({ message: error.message || 'An unknown error occured!' })
})


mongoose
    .connect('mongodb+srv://pmhoff:supersecretpass@cluster0.exaqb3t.mongodb.net/mern?retryWrites=true&w=majority')
    .then(() => {
        app.listen(5000, () => {
            console.log('App listening on Port')
        });
    })
    .catch((e) => {
        console.log(e)
    })

