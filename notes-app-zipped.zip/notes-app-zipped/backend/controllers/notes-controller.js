const uuid = require("uuid").v4;
const HttpError = require("../models/http-error");
const { validationResult } = require("express-validator");
const Note = require("../models/note");
const User = require("../models/user");
const { default: mongoose } = require("mongoose");

const getNotes = (req, res) => {
  res.json({ message: "it works.." });
};

const getNotesByUserId = async (req, res, next) => {
  const userId = req.params.uid;

  let userWithNotes;
  try {
    userWithNotes = await User.find({ owner: userId }).populate('notes')
  } catch (err) {
    console.log(err);
    return next(new HttpError("Fetching users error", 500));
  }

  if (!userWithNotes || userWithNotes.notes.length === 0) {
    return next(
      new HttpError("Could not find notes for the provided id.", 404)
    );
  }

  res.json({ notes: userWithNotes.map((note) => note.toObject({ getters: true })) });
};

const addNote = async (req, res, next) => {
  const {
    meta,
    notebook,
    owner,
    note,
    subNotes,
    examples,
    term,
    definition,
    imageHyperText,
    imageUrl,
  } = req.body;

  if (!meta || !owner)
    return next(new HttpError("Must contain both a meta and owner field"));
  if (meta.trim() == "" || owner.trim() == "")
    return next(new HttpError("Must contain both a meta and owner field"));

  //Find the userID:
  let user;

  try {
    user = await User.findById(owner);
  } catch (err) {
    console.log(err);
    const error = new HttpError("Error with db search for users..", 500);
    return next(error);
  }

  if (!user) return next(new HttpError("There is no user with that ID", 404));

  console.log(user);

  let createdNote;

  if (meta === "note") {
    if (!note) {
      return next(
        new HttpError(
          "A meta of type 'Note' needs an entry for the note field.",
          404
        )
      );
    }

    createdNote = new Note({
      meta,
      owner: user,
      note,
    });

    if (subNotes) {
      if (!Array.isArray(subNotes))
        return next(new HttpError("Subnotes error..", 404));

      createdNote.subNotes = subNotes;
    }
    if (examples) {
      if (!Array.isArray(examples))
        return next(new HttpError("Examples error..", 404));
      // createdNote = { ...createdNote, examples }
      createdNote.examples = examples;
    }

    //THESE MUST ALL RETURN ERROS
    if (imageHyperText)
      return next(
        new HttpError("Notes of type 'note' cannot have this field"),
        404
      );
    if (imageUrl)
      return next(
        new HttpError("Notes of type 'note' cannot have this field"),
        404
      );
    if (term)
      return next(
        new HttpError("Notes of type 'note' cannot have this field"),
        404
      );
    if (definition)
      return next(
        new HttpError("Notes of type 'note' cannot have this field"),
        404
      );
  }

  if (meta === "vocab") {
    if (!term || !definition)
      return next(
        new HttpError(
          "Vocab must have an entry for both term and definition",
          404
        )
      );

    createdNote = new Note({
      meta,
      owner: user,
      term,
      definition,
    });

    // if (subNotes) validateInsertSubNotes(subNotes, createdNote)  /*createdNote = { ...createdNote, subNotes };*/
    if (subNotes) {
      if (!Array.isArray(subNotes))
        return next(new HttpError("Subnotes error..", 404));

      createdNote.subNotes = subNotes;
    }
    if (examples) {
      if (!Array.isArray(examples))
        return next(new HttpError("Examples error..", 404));
      // createdNote = { ...createdNote, examples }
      createdNote.examples = examples;
    }

    //THESE MUST ALL RETURN ERRORS
    if (imageHyperText)
      return next(
        new HttpError("Notes of type 'vocab' cannot have this field"),
        404
      );
    if (imageUrl)
      return next(
        new HttpError("Notes of type 'vocab' cannot have this field"),
        404
      );
    if (note)
      return next(
        new HttpError("Notes of type 'vocab' cannot have this field"),
        404
      );
  }

  if (meta === "img") {
    if (!imageHyperText || !imageUrl)
      return next(
        new HttpError(
          "Img notes must have an entry for both imageHyperText and imageUrl",
          404
        )
      );

    createdNote = new Note({
      meta,
      owner: user,
      imageHyperText,
      imageUrl,
    });

    // if (subNotes) validateInsertSubNotes(subNotes, createdNote)  /*createdNote = { ...createdNote, subNotes };*/
    if (subNotes) {
      if (!Array.isArray(subNotes))
        return next(new HttpError("Subnotes error..", 404));

      createdNote.subNotes = subNotes;
    }
    if (examples) {
      if (!Array.isArray(examples))
        return next(new HttpError("Examples error..", 404));
      // createdNote = { ...createdNote, examples }
      createdNote.examples = examples;
    }

    //THESE MUST ALL RETURN ERRORS
    if (term)
      return next(
        new HttpError("Notes of type 'img' cannot have this field"),
        404
      );
    if (definition)
      return next(
        new HttpError("Notes of type 'img' cannot have this field"),
        404
      );
    if (note)
      return next(
        new HttpError("Notes of type 'img' cannot have this field"),
        404
      );
  }

  console.log(createdNote);

  try {
    const sess = await mongoose.startSession();
    sess.startTransaction();
    await createdNote.save({ session: sess });
    user.notes.push(createdNote);
    await user.save({ session: sess });
    await sess.commitTransaction();
  } catch (err) {
    console.log(err);
    return next(new HttpError("Error saving the note", 404));
  }

  res.status(201).json({ message: createdNote });
};

const deleteNote = async (req, res, next) => {
  const noteId = req.params.nid;

  let note;
  try {
    note = await Note.findById(noteId).populate("owner");
    //^^Allows us to see the relational data with the other Model that is referenced by this model. (In this case, User)
  } catch (err) {
    console.log(err);
    return next(new HttpError("Error with finding the note of that ID", 500));
  }

  if (!note) return next("Error finding the note of that ID.", 400);

  try {
    const sess = await mongoose.startSession();
    sess.startTransaction();
    await note.remove({ session: sess });
    note.owner.notes.pull(note);
    await note.owner.save({ session: sess });
    await sess.commitTransaction();
  } catch (err) {
    console.log(err);
    return next(new HttpError("Error deleting the note", 404));
  }

  res.status(200).json({ message: "Deleted note" });
};

exports.getNotes = getNotes;
exports.getNotesByUserId = getNotesByUserId;
exports.addNote = addNote;
exports.deleteNote = deleteNote;
// exports.login = login;
