const mongoose = require('mongoose')

const Schema = mongoose.Schema

const noteSchema = new Schema({ 
    meta: { type: String, required: true },
    note: { type: String, required: false },
    owner: { type: mongoose.Types.ObjectId, required: true, ref: 'User' },
    // notebook: { type: mongoose.Types.ObjectId, required: true, ref: 'Notebook' },
    subNotes: [{ type: String, required: false }],
    examples: [{ type: String, required: false }],
    term: { type: String, required: false },
    definition: { type: String, required: false },
    imageHyperText: { type: String, required: false },
    imageUrl: { type: String, required: false }
});
    //Meta selection will be a dropdown: 
        //Note:
            //Note!
            //subNotes?
            //examples?
            //imageHyperText?
                //imageUrl!
            //owner!
        //Vocab:
            //Term!
            //Definition!
            //subNotes?
            //examples?
            //imageHyperText?
                //imageUrl

        //In both back&front end will check depending on the meta that the user has input values for certain fields.
        //I may need to have the notebook field instead of the owner field.


module.exports = mongoose.model('Note', noteSchema);

//The front end will determine how the data is displayed based on the meta. Meta values can be
    //Note:
    //Vocab:
        //term
        //definition
        //
    //ImgNote:
        //note
        //imgUrl


//The user will login then recieve a feed of all of their noteBook objects.
//Each noteBook object has an array of notes[]