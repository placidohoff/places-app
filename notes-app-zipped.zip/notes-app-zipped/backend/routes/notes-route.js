const express = require('express');
// const { check } = require('express-validator')

const notesController = require('../controllers/notes-controller');

const router = express.Router();

// const DUMMY_PLACES:

const NOTES = {
    notebookName: ''
}

router.get('/', notesController.getNotes)

router.get('/:uid', notesController.getNotesByUserId)

router.post('/', notesController.addNote);

router.delete('/:nid', notesController.deleteNote);

module.exports = router;