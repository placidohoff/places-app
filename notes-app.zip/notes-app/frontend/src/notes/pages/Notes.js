import React from 'react'

/**
* @author
* @function Notes
**/

export const Notes = (props) => {
  return(
    <div>Notes</div>
   )

 }