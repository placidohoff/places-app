import React, { useCallback, useReducer } from "react";
import { Input } from "../components/FormElements/Input";
import {
  VALIDATOR_EMAIL,
  VALIDATOR_MINLENGTH,
  VALIDATOR_REQUIRE,
} from "../../shared/util/validators";
import  Button  from "../components/FormElements/Button";



import "./NewNotebook.css";

const formReducer = (state, action) => {
  switch (action.type) {
    case "INPUT_CHANGE":
      let formIsValid = true;
      for (const inputId in state.inputs) {
        if (inputId === action.inputId) {
          formIsValid = formIsValid && action.isValid;
        } else {
          formIsValid = formIsValid && state.inputs[inputId].isValid;
        }
      }
      return {
        ...state,
        input: {
          ...state.inputs,
          [action.inputId]: { value: action.value, isValid: action.isValid },
        },
        isValid: formIsValid,
      };
    default:
  }
};

export const NewNotebook = (props) => {
  const [formState, dispatch] = useReducer(formReducer, {
    inputs: {
      title: {
        value: "",
        isValid: false,
      },
      description: {
        value: "",
        isValid: false,
      },
    },
    isValid: false,
  });

  const inputHandler = useCallback((id, value, isValid) => {
    dispatch({
      type: "INPUT_CHANGE",
      value: value,
      isValid: isValid,
      id: id,
    });
  }, []);
  //^^useCallback prevents the function from being re-rendered/re-created which would lead to a new instance of it being passed to <Input /> which would be caught by its useEffect and lead to an infinite loop.

  const descriptionInputHandler = useCallback((id, value, isValid) => {}, []);

  return (
    <form className="notebook-form">
      <Input
        id="Title"
        element="input"
        type="text"
        label="Title"
        onInput={inputHandler}
        validators={[VALIDATOR_REQUIRE()]}
        errorText="The title is invalid"
      />
      <Input
        id="Description"
        element="textarea"
        type="text"
        label="Description"
        onInput={inputHandler}
        validators={[VALIDATOR_MINLENGTH(5)]}
        errorText="The description is invalid"
      />

      <Button type="submit" disabled={!formState.isValid}>
        Add Note
      </Button>
    </form>
  );
};
