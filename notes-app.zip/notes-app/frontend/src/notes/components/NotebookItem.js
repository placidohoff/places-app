import React, { useState } from "react";
import Card from "../../shared/components/UIElements/Card";
import "./NotebookItem.css";
import Button from "./FormElements/Button";
import { Modal } from "../../shared/components/UIElements/Modal";

/**
 * @author
 * @function NotebookItem
 **/

export const NotebookItem = (props) => {
  const [openDeleteModal, setOpenDeleteModal] = useState(false);

  const openDeleteHandler = () => setOpenDeleteModal(true);

  const closeDeleteHandler = () => setOpenDeleteModal(false);

  return (
    <>
      <Modal
        show={openDeleteModal}
        onCancel={closeDeleteHandler}
        header="Are you sure you want to delete this notebook?"
        contentClass="notebook-item__modal-content"
        footerClass="notebook-item__modal-actions"
        footer={<Button onClick={closeDeleteHandler}>CLOSE</Button>}
      >
        <div style={{"height": "10rem", "width":"100%"}}>
          This will permanetly delete the entire notebook.
        </div>
      </Modal>
      <li className="notebook-item">
        <Card className="notebook-item__content">
          <div className="notebook-item__info">
            <h2>{props.notebook.title}</h2>
          </div>
          <div className="notebook-item__actions">
            <Button to={`/notes/${props.notebook.id}`}>OPEN</Button>
            <Button onClick={openDeleteHandler} danger>
              DELETE
            </Button>
          </div>
        </Card>
      </li>
    </>
  );
};
