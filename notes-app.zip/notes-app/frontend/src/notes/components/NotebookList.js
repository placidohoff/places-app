import React from "react";
import { NotebookItem } from "./NotebookItem";
import "./NotebookList.css";
import Card from "../../shared/components/UIElements/Card";

/**
 * @author
 * @function NotebookList
 **/

export const NotebookList = (props) => {
  if (props.items.length === 0) {
    return (
      <div className="place-list center">
        <Card>
          <h2>No notebooks found. Please create one</h2>
          <button>Create Notebook</button>
        </Card>
      </div>
    );
  }

  return (
    <ul className="place-list" style={{"listStyle": "none"}}>
      {props.items.map((item) => (
        <NotebookItem notebook={item} key={item.id} id={item.id} title />
      ))}
    </ul>
  );
};
