import React from 'react'
import { useParams } from 'react-router-dom'
import { NotebookList } from '../../notes/components/NotebookList'

/**
* @author
* @function UserNotes
**/

const notebooks = [
    {
        id: 'nbk0',
        ownerId: 'u1',
        title: 'Biology',
        chapters: [
            {
                id: 'nbk0chp1',
                notebookId: 'nbk0',
                chapterTitle: 'Body Chemistry',
                notes: [
                    {
                        id: 'nbk0chp1n1',
                        chapterId: 'nbk0chp1',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                    {
                        id: 'nbk0chp1n2',
                        chapterId: 'nbk0chp1',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                    {
                        id: 'nbk0chp1n3',
                        chapterId: 'nbk0chp1',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                ] 
            },
            {
                id: 'nbk0chp2',
                notebookId: 'nbk0',
                chapterTitle: 'Body Cells',
                notes: [
                    {
                        id: 'nbk0chp1n1',
                        chapterId: 'nbk0chp2',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                    {
                        id: 'nbk0chp1n2',
                        chapterId: 'nbk0chp2',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    }
                ] 
            },
        ]
    },
    {
        id: 'nbk1',
        ownerId: 'u2',
        title: 'Chemistry',
        chapters: [
            {
                id: 'nbk1chp1',
                notebookId: 'nbk1',
                chapterTitle: 'Body Chemistry',
                notes: [
                    {
                        id: 'nbk1chp1n1',
                        chapterId: 'nbk1chp1',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                    {
                        id: 'nbk1chp1n2',
                        chapterId: 'nbk1chp1',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                    {
                        id: 'nbk1chp1n3',
                        chapterId: 'nbk1chp1',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                ] 
            },
            {
                id: 'nbk1chp2',
                notebookId: 'nbk1',
                chapterTitle: 'Body Cells',
                notes: [
                    {
                        id: 'nbk1chp1n1',
                        chapterId: 'nbk1chp2',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    },
                    {
                        id: 'nbk1chp1n2',
                        chapterId: 'nbk1chp2',
                        meta: 'note',
                        note: 'yada yada yada',
                        
                    }
                ] 
            },
        ]
    },
   
]

export const UserNotes = (props) => {
    const userId = useParams().userId
    const filteredNotebooks = notebooks.filter(nb => nb.ownerId === userId) 
  return(
    <NotebookList items={filteredNotebooks} />
   )

 }