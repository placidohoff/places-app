import React from "react";
import { UserList } from "../components/UserList";

/**
 * @author
 * @function Users
 **/

export const Users = (props) => {
  const USERS = [
    {
      id: "u1",
      name: "Test User",
      image: 'https://thumbs.dreamstime.com/b/user-silhouette-button-icon-illustration-design-85107431.jpg',
      notes: ['0', '1', '2']
    },
    {
      id: "u2",
      name: "Test User",
      image: 'https://thumbs.dreamstime.com/b/user-silhouette-button-icon-illustration-design-85107431.jpg',
      notes: ['0', '1', '2']
    },
    {
      id: "u3",
      name: "Test User",
      image: 'https://thumbs.dreamstime.com/b/user-silhouette-button-icon-illustration-design-85107431.jpg',
      notes: ['0', '1', '2']
    },
  ];
  return <UserList items={USERS} />;
};
