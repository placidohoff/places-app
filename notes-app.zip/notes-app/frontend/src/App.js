import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Switch,
} from "react-router-dom";

import { Users } from "./user/pages/User";
import { Notes } from "./notes/pages/Notes";
import { MainNavigation } from "./shared/components/Navigation/MainNavigation";
import { UserNotes } from "./user/pages/UserNotes";
import { NewNotebook } from "./notes/pages/NewNotebook";

const App = () => {
  return (
    <Router>
      <MainNavigation />
      <main>
        <Switch>
          {/* <Route exact path="/notes">
            <Notes />
          </Route> */}
          <Route exact path="/:userId/notes">
            <UserNotes />
          </Route>
          <Route exact path="/notes/new">
            <NewNotebook />
          </Route>
          <Route exact path="/">
            <Users />
          </Route>
          <Redirect to="/" />
        </Switch>
      </main>
    </Router>
  );
};

export default App;
