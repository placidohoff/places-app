const mongoose = require('mongoose');
// const note = require('./note');

const Schema = mongoose.Schema

const noteSchema = require('./note').schema

const noteBookSchema = new Schema({ 
    title: { type: String, required: true },
    owner: { type: mongoose.Types.ObjectId, required: true, ref: 'User' },
    notes: [{type: Note, required: true }]
    // meta: { type: String, required: true },
    // note: { type: String, required: true },
    // subNotes: [{ type: String, required: false }],
    // examples: [{ type: String, required: false }],
    // term: { type: String, required: false },
    // definition: { type: String, required: false },
    // imageUrl: { type: String, required: false },
    // owner: { type: mongoose.Types.ObjectId, required: true, ref: 'User' }
});

module.exports = mongoose.model('Note', noteSchema);