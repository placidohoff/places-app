const express = require('express');
const { check } = require('express-validator')

const usersController = require('../controllers/usersController');

const router = express.Router();


//ROUTES:
router.get('/', usersController.getUsers);

router.post('/signup',
[
    check('name')
        .not()
        .isEmpty(),
    check('password')
        .isLength({min: 6}),
    check('email')
        .normalizeEmail()
        .isEmail()
],
usersController.signup)

router.post('/login', usersController.login)



module.exports = router;