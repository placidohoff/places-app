const express = require('express');

const router = express.Router();

// const DUMMY_PLACES:

const NOTES = {
    notebookName: ''
}

router.get('/', (req, res) => {
    console.log('GET Notes');
    res.json({message: 'It Works!'})
})

module.exports = router;