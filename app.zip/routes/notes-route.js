const express = require('express');
// const { check } = require('express-validator')

const notesController = require('../controllers/notes-controller');

const router = express.Router();

// const DUMMY_PLACES:

const NOTES = {
    notebookName: ''
}

router.get('/', notesController.getNotes)

router.post('/', notesController.addNote);

module.exports = router;