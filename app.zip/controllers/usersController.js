let USERS = {
    id: 'u1',
    name: 'Max Schwarz',
    email: 'test@test.com',
    password: 'testing'
}

const getUsers = (req, res, next) => {
    
}

const signup = (req, res, next) => {

}

const login = (req, res, next) => {

}