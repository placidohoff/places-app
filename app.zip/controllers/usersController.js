const uuid = require('uuid').v4
const HttpError = require("../models/http-error");
const { validationResult } = require('express-validator')
const User = require('../models/user')

//THIS DATA IS NOT ATOMIC
let USERS = [
    {
        id: 'u1',
        name: 'Placido',
        email: 'test@test.com',
        password: 'testing'
    }
]

const getUsers = async (req, res, next) => {
    let users
    try {
        users = await User.find({}, '-password')
    } catch (err) {
        return next(new HttpError('Fetching users failed.', 500))
    }

    // console.log(users)
    // res.json(users)
    res.json({ users: users.map(user => user.toObject({ getters: true })) })
}

const signup = async (req, res, next) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
        console.log(errors)
        let error = new HttpError("Invalid data entry", 422)
        // throw new HttpError("Invalid data entry", 422)
        //With async methods, throw shuts down the server if hit
        return next(error)
    }
    const { name, email, password, places } = req.body


    let existingUser
    try {
        existingUser = await User.findOne({ email: email })
    } catch (err) {
        const error = new HttpError("Error with db search for users..", 500)
        return next(error)
    }

    if (existingUser) {
        const error = new HttpError("User already exist.", 422)
        return next(error)
    }

    let createdUser = new User({
        name,
        email,
        image: 'https://thumbs.dreamstime.com/b/user-silhouette-button-icon-illustration-design-85107431.jpg',
        password,
        places,
        notes: []
    })

    try {
        await createdUser.save();
    } catch (err) {
        const error = new HttpError("Error saving user. Please try again", 500)
        return next(error)
    }

    res.status(201).json({ user: createdUser.toObject({ getters: true }) })
}

const login = async (req, res, next) => {
    const { email, password } = req.body

    let existingUser
    try {
        existingUser = await User.findOne({ email: email })
    } catch (err) {
        const error = new HttpError("Error searching database to find user", 500)
        return next(error)
    }

    if (!existingUser || existingUser.password !== password) {
        return next(new HttpError("Error logging in..", 404))
    }

    res.json({ message: 'Logged in!' })
}

exports.getUsers = getUsers;
exports.signup = signup;
exports.login = login;