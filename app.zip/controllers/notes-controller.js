const uuid = require('uuid').v4
const HttpError = require("../models/http-error");
const { validationResult } = require('express-validator')
const Note = require('../models/user')

const getNotes = (req, res) => {
    res.json({message: 'it works..'})
}

const addNote = async (req, res) => {
    // const errors = validationResult(req)
    // //Will check primary/absolute requirements of: 'meta', and 'owner'
    //     //The rest is dependent on the meta 
    // if (!errors.isEmpty()) {
    //     console.log(errors)
    //     let error = new HttpError("Invalid data entry", 422)
    //     return next(error)
    // }
    const { meta, owner } = req.body

    // let createdNote;

    // if(meta === 'note'){

    // }
    // if(meta === 'vocab'){
         
    // }
    console.log(req.body)
    res.status(200).json({message: 'posted..'})


    // let createdUser = new User({
    //     name,
    //     email,
    //     image: 'https://thumbs.dreamstime.com/b/user-silhouette-button-icon-illustration-design-85107431.jpg',
    //     password,
    //     places,
    //     notes: []
    // })

    // try {
    //     await createdUser.save();
    // } catch (err) {
    //     const error = new HttpError("Error saving user. Please try again", 500)
    //     return next(error)
    // }

    // res.status(201).json({ user: createdUser.toObject({ getters: true }) })
}

exports.getNotes = getNotes;
exports.addNote = addNote;
// exports.login = login;