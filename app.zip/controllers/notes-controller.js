const uuid = require("uuid").v4;
const HttpError = require("../models/http-error");
const { validationResult } = require("express-validator");
const Note = require("../models/user");
const { create } = require("../models/user");

const getNotes = (req, res) => {
  res.json({ message: "it works.." });
};

const addNote = async (req, res, next) => {
  // const errors = validationResult(req)
  // //Will check primary/absolute requirements of: 'meta', and 'owner'
  //     //The rest is dependent on the meta
  // if (!errors.isEmpty()) {
  //     console.log(errors)
  //     let error = new HttpError("Invalid data entry", 422)
  //     return next(error)
  // }
  const {
    meta,
    notebook,
    owner,
    note,
    subNotes,
    examples,
    term,
    definition,
    imageHyperText,
    imageUrl,
  } = req.body;

  if(!meta || !owner) return next(new HttpError("Must contain both a meta and owner field"))
  if(meta.trim() == "" || owner.trim() == "") return next(new HttpError("Must contain both a meta and owner field"))

  let createdNote;

  if (meta === "note") {
    if (!note) {
      return next(
        new HttpError(
          "A meta of type 'Note' needs an entry for the note field.",
          404
        )
      );
    }
  }
  if (meta === "vocab") {
    if (!term || !definition)
      return next(
        new HttpError(
          "Vocab must have an entry for both term and definition",
          404
        )
      );
    createdNote = {
      meta: meta,
      owner: owner,
      term: term,
      definition: definition,
    };

    // if (subNotes) validateInsertSubNotes(subNotes, createdNote)  /*createdNote = { ...createdNote, subNotes };*/ 
    if (subNotes){
      if(!Array.isArray(subNotes)) return next(new HttpError("Subnotes error..", 404))
      createdNote = { ...createdNote, subNotes }
    } 
    if (examples){
      if(!Array.isArray(examples)) return next(new HttpError("Examples error..", 404))
      createdNote = { ...createdNote, examples }
    } 
    if (term){
      createdNote = { ...createdNote, term }
    } /*= { ...createdNote, term };*/
    if (imageHyperText) createdNote = validateInsertImageHyperText(imageHyperText, createdNote, next) /*createdNote = { ...createdNote, imageHyperText };*/
    if (imageUrl) createdNote = validateInsertImageUrl(imageUrl, createdNote, next) /*createdNote = { ...createdNote, imageUrl };*/


  }
  console.log(createdNote);
  res.status(200).json({ message: "posted.." });

  // let createdUser = new User({
  //     name,
  //     email,
  //     image: 'https://thumbs.dreamstime.com/b/user-silhouette-button-icon-illustration-design-85107431.jpg',
  //     password,
  //     places,
  //     notes: []
  // })

  // try {
  //     await createdUser.save();
  // } catch (err) {
  //     const error = new HttpError("Error saving user. Please try again", 500)
  //     return next(error)
  // }

  // res.status(201).json({ user: createdUser.toObject({ getters: true }) })
};

const validateInsertSubNotes = async (subNotes, createdNote, next) => {
  if (subNotes !== 'test') return next(new HttpError("Subnotes error...", 404))
  
}

const validateInsertExamples = (examples, createdNote) => {
  return createdNote
}

const validateInsertTerm = (term, createdNote) => {
  return createdNote
}

const validateInsertImageHyperText = (imageHyperText, createdNote) => {
  return createdNote
}

const validateInsertImageUrl = (imageUrl, createdNote) => {
  return createdNote
}

exports.getNotes = getNotes;
exports.addNote = addNote;
// exports.login = login;
