const uuid = require("uuid").v4;
const HttpError = require("../models/http-error");
const { validationResult } = require("express-validator");
const Note = require("../models/user");

const getNotes = (req, res) => {
  res.json({ message: "it works.." });
};

const addNote = async (req, res, next) => {
  // const errors = validationResult(req)
  // //Will check primary/absolute requirements of: 'meta', and 'owner'
  //     //The rest is dependent on the meta
  // if (!errors.isEmpty()) {
  //     console.log(errors)
  //     let error = new HttpError("Invalid data entry", 422)
  //     return next(error)
  // }
  const {
    meta,
    notebook,
    owner,
    note,
    subNotes,
    examples,
    term,
    definition,
    imageHyperText,
    imageUrl,
  } = req.body;

  let createdNote;

  if (meta === "note") {
    if (!note) {
      return next(
        new HttpError(
          "A meta of type 'Note' needs an entry for the note field.",
          404
        )
      );
    }
  }
  if (meta === "vocab") {
    if (!term || !definition)
      return next(
        new HttpError(
          "Vocab must have an entry for both term and definition",
          404
        )
      );
    createdNote = {
      meta: meta,
      owner: owner,
      term: term,
      definition: definition,
    };

    if (subNotes) createdNote = { ...createdNote, subNotes };
    if (examples) createdNote = { ...createdNote, examples };
        //Must check if examples is an array
    if (term) createdNote = { ...createdNote, term };
    if (imageHyperText) createdNote = { ...createdNote, imageHyperText };
    if (imageUrl) createdNote = { ...createdNote, imageUrl };


    /* 
        meta: { type: String, required: true },
    note: { type: String, required: false },
    owner: { type: mongoose.Types.ObjectId, required: true, ref: 'User' },
    // notebook: { type: mongoose.Types.ObjectId, required: true, ref: 'Notebook' },
    subNotes: [{ type: String, required: false }],
    examples: [{ type: String, required: false }],
    term: { type: String, required: false },
    definition: { type: String, required: false },
    imageHyperText: { type: String, required: false },
    imageUrl: { type: String, required: false }
    */
  }
  console.log(createdNote);
  res.status(200).json({ message: "posted.." });

  // let createdUser = new User({
  //     name,
  //     email,
  //     image: 'https://thumbs.dreamstime.com/b/user-silhouette-button-icon-illustration-design-85107431.jpg',
  //     password,
  //     places,
  //     notes: []
  // })

  // try {
  //     await createdUser.save();
  // } catch (err) {
  //     const error = new HttpError("Error saving user. Please try again", 500)
  //     return next(error)
  // }

  // res.status(201).json({ user: createdUser.toObject({ getters: true }) })
};

exports.getNotes = getNotes;
exports.addNote = addNote;
// exports.login = login;
