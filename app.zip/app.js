const express = require('express');
const bodyParser = require('body-parser');

const placesRoutes = require('./routes/places-route');
const HttpError = require('./models/http-error')

const app = express();

//We must parse incoming data for post routes etc:
    //must parse before any other middleware?
app.use(bodyParser.json());


//Routing Middleware:
    //Routes will only be forwarded to the respective middleware if it is prepended with the specified route prefix
app.use('/api/places', placesRoutes);

app.use((error, req, res, next) => {
    const error = new HttpError("Cannot find route", 404);
    throw error;
})

//Middleware with 4params is registered as error handler:
app.use((error, req, res, next) => {
    if(res.headerSent){
        return next(error)
    }
    res.status(error.code || 500)
    res.json({message: error.message || 'An unknown error occured!'})
})

app.listen(5000);